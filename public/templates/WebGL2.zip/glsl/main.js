/**
 * シェーダーを作成する関数
 */
const createShader = (gl, type, source) => {
    const shader = gl.createShader(type);
    if (!shader) throw new Error('シェーダーの作成に失敗しました');

    gl.shaderSource(shader, source);
    gl.compileShader(shader);

    const success = gl.getShaderParameter(shader, gl.COMPILE_STATUS);
    if (success) return shader;

    const info = gl.getShaderInfoLog(shader);
    gl.deleteShader(shader);
    throw new Error('シェーダーのコンパイルに失敗しました' + info);
};

/**
 * シェーダープログラムを作成する関数
 */
const createProgram = (gl, vertexShader, fragmentShader) => {
    const program = gl.createProgram();
    if (!program) throw new Error('プログラムの作成に失敗しました');
    
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);

    const success = gl.getProgramParameter(program, gl.LINK_STATUS);
    if (success) return program;

    const info = gl.getProgramInfoLog(program);
    gl.deleteProgram(program);
    throw new Error('プログラムのリンクに失敗しました' + info);
};

/**
 * 板ポリゴンを作成する関数
 */
const setGeometry = (gl) => {
    gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
    gl.bufferData(
        gl.ARRAY_BUFFER,
        new Float32Array([
            -1, -1,
            -1, 1,
            1, -1,
            -1, 1,
            1, 1,
            1, -1
        ]),
        gl.STATIC_DRAW
    );
};

/**
 * リサイズを反映させる関数
 */
const onResize = (c, gl, u) => {
    if (c.width === c.clientWidth && c.height === c.clientHeight) return;
    c.width = c.clientWidth;
    c.height = c.clientHeight;

    gl.viewport(0, 0, c.width, c.height);
    u.resolution.x = c.width;
    u.resolution.y = c.height;
};

/**
 * マウス座標を更新する関数
 */
const onMouseMove = (e, u) => {
    const { offsetX, offsetY } = e;
    u.mouse.x = offsetX / u.resolution.x;
    u.mouse.y = -offsetY / u.resolution.y + 1;
};

(async () => {
    const vertex = await(await fetch('./vertex.glsl')).text();
    const fragment = await(await fetch('./fragment.glsl')).text();
    console.log(vertex, fragment);

    const c = document.querySelector('#c');
    const gl = c.getContext('webgl2') ?? console.log('webgl2 unsupported');

    const uniforms = {
        resolution: { x: c.clientWidth, y: c.clientHeight },
        mouse: { x: 0, y: 0 },
        time: 0
    }

    const vertexShader = createShader(gl, gl.VERTEX_SHADER, vertex);
    const fragmentShader = createShader(gl, gl.FRAGMENT_SHADER, fragment);
    const program = createProgram(gl, vertexShader, fragmentShader);
    gl.useProgram(program);

    setGeometry(gl);

    const positionLocation = gl.getAttribLocation(program, 'a_position');
    gl.enableVertexAttribArray(positionLocation);
    gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);

    const resolutionLocation = gl.getUniformLocation(program, 'u_resolution');
    const timeLocation = gl.getUniformLocation(program, 'u_time');
    const mouseLocation = gl.getUniformLocation(program, 'u_mouse');

    gl.uniform2f(resolutionLocation, c.width, c.height);
    gl.uniform1f(timeLocation, 0);
    gl.uniform2f(mouseLocation, uniforms.mouse.x, uniforms.mouse.y);

    c.addEventListener('mousemove', (e) => onMouseMove(e, uniforms));
    window.addEventListener('resize', () => onResize(c, gl, uniforms));

    const startTime = new Date();
    const animate = () => {
        requestAnimationFrame(animate);
        const elapsedTime = (new Date().getTime() - startTime.getTime()) / 1000;
        uniforms.time = elapsedTime;

        gl.uniform2f(resolutionLocation, uniforms.resolution.x, uniforms.resolution.y);
        gl.uniform1f(timeLocation, uniforms.time);
        gl.uniform2f(mouseLocation, uniforms.mouse.x, uniforms.mouse.y);
        gl.drawArrays(gl.TRIANGLES, 0, 6);
        gl.flush();
    };
    animate();
})();
